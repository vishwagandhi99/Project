# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html
'''import mysql.connector

class AmazonScrappingPipeline(object):
    def __init__(self):
        self.create_conn()
        self.create_tb()

    def create_conn(self):
        self.conn = mysql.connector.connect(host='localhost', user='root', database='scrape', passwd='')
        self.curr = self.conn.cursor()

    def create_tb(self):
        self.curr.execute("""DROP TABLE IF EXISTS quotes""")
        self.curr.execute("""
        CREATE TABLE quotes(
        title text,
        author text,
        tag text)""")

    def process_item(self, item, spider):
        self.store_val(item)
        return item

    def store_val(self, items):
        for i in range(12):
            self.curr.execute("""insert into amazon(book_name,author,price,img_link) values(%s,%s,%s,%s)""",
                              (items['book_name'][0],
                               items['author'][0],
                               items['price'],
                               items['image'][0]))
        self.conn.commit()
'''