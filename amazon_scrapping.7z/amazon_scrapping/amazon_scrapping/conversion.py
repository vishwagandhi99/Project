import json
import xlsxwriter
import mysql.connector
import mysql.connector
import os

con = mysql.connector.connect(host='localhost',user='root',database='scrape',passwd='')
cursor = con.cursor()
conn = mysql.connector.connect(host='localhost',user='root',database='scrape',passwd='')
curr = conn.cursor()
with open('../op.json') as f:
  data = json.load(f)

# Output: {'name': 'Bob', 'languages': ['English', 'Fench']}
#kk=data[0]['ratings'][0]
#print(kk)
if os.path.exists("../data_scraped.xlsx"):
    os.remove("../data_scraped.xlsx")
else:
    workbook = xlsxwriter.Workbook('../data_scraped.xlsx')
    sheet = workbook.add_worksheet('data')
    key = list(data[0].keys())
    #print(key[1])
    for i in range(5):
        sheet.write(0,i,key[i])
    i1,j1=1,0
    for i in data:
        j1 = 0
        i1 += 1
        for j in i.values():
            if(j == [] ):
                sheet.write(i1, j1, '0')
            else:
                sheet.write(i1,j1,j[0])
            j1 += 1
    workbook.close()
def validate_string(val):
    if val != []:
       return val
    else:
        return ["0"]
for i, item in enumerate(data):
    book_name = (validate_string(item.get("book_name", None)))[0]
    author = validate_string(item.get("author", None))[0]
    ratings = validate_string(item.get("ratings", None))[0]
    price = validate_string(item.get("price", None))[0]
    image = validate_string(item.get("image", None))[0]

    cursor.execute("INSERT INTO amazon (book_name,author,price,reviews,img_link) VALUES (%s,%s,	%s,%s,%s)", (book_name,author,price,ratings,image))
con.commit()
con.close()
