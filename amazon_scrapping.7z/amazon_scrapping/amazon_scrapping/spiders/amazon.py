# -*- coding: utf-8 -*-
import scrapy
from ..items import AmazonScrappingItem
import pandas as pd
class AmazonSpider(scrapy.Spider):
    name = 'amazon'
    start_urls = ['https://www.amazon.in/s?k=books&ref=nb_sb_noss_2']
    page = 2

    def parse(self, response):
        # items = AmazonScrappingItem()
        # l2 = []

        # book_name = response.css('.a-color-base .a-text-normal::text').extract()
        # author = response.css('.a-color-secondary .a-size-base:nth-child(2)::text').extract()
        # for x in author:
        #     x.strip()
        #     l2.append(x.replace('\n', '').replace(' ', ''))
        # author = [value for value in l2 if value != '']
        # #reviews = response.css('span::attr(aria-label)').extract()
        # review = response.css('.a-size-small .a-link-normal .a-size-base::text').extract()
        # price = response.css('.a-spacing-top-small .a-price-whole::text').extract()
        # image = response.css('.s-image::attr(src)').extract()

        # items['book_name'] = book_name
        # items['author'] = author
        # items['review'] = review
        # items['price'] = price
        # items['image'] = image

        # yield items

        # div = response.css('.a-section a-spacing-medium')
        div = response.xpath("//div[contains(@class,'s-result-list') and contains(@class, 's-search-results') and not(contains(@class,'s-main-slot'))]")
        
        result_items = div.xpath("//div[contains(@class,'s-result-item')]")
        
        for result in result_items:
            item = AmazonScrappingItem()
            block = scrapy.selector.unified.Selector(text=result.extract())
            book_name = block.css('.a-color-base.a-text-normal::text').extract()
            author = block.css('.a-color-secondary .a-size-base:nth-child(2)::text').extract()
            l2 = []
            for x in author:
                x.strip()
                l2.append(x.replace('\n', '').replace(' ', ''))
            author = [value for value in l2 if value != '']
            # reviews = response.css('span::attr(aria-label)').extract()
            reviews = block.css('.a-size-small .a-link-normal .a-size-base::text').extract()
            price = block.css('.a-spacing-top-small .a-price-whole::text').extract()
            image = block.css('.s-image::attr(src)').extract()

            item['book_name'] = book_name
            item['author'] = author
            item['reviews'] = reviews
            item['price'] = price
            item['image'] = image

            yield item

        next_page = "https://www.amazon.in/s?k=books&page="+str(AmazonSpider.page)+"&qid=1584962028&ref=sr_pg_"+str(AmazonSpider.page)
        if AmazonSpider.page <= 3:
            AmazonSpider.page += 1
            yield response.follow(next_page,callback=self.parse)