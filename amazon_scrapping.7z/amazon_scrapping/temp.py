'''dic=[{"book_name": ["Percy Jackson and the Sea of Monsters"], "author": ["RickRiordan"], "ratings": ["2,539"], "price": [], "image": ["https://m.media-amazon.com/images/I/817V-J17ZvL._AC_UY218_ML3_.jpg"]},{"book_name": ["Percy Jackson and the Sea of Monsters"], "author": ["RickRiordan"], "ratings": ["2,539"], "price": [], "image": ["https://m.media-amazon.com/images/I/817V-J17ZvL._AC_UY218_ML3_.jpg"]}]
for i in dic:
    for j in i.values():
        print(j)
        if(j==[]):
            print('heyy')'''
import mysql.connector

con = mysql.connector.connect(host='localhost',user='root',database='scrape',passwd='')
cursor = con.cursor()
json_obj=[
	{
		"person": ["John"],
		"year": ['2018'],
		"company": "Google"
	},
	{
		"person": ["Sam"],
		"year": ['2017'],
		"company": ["IBM"]
	},
	{
		"person": ["Jeff"],
		"year": ['2014'],
		"company": ["Yahoo"]
	}
]

def validate_string(val):
    if val != []:
       return val
    else:
        return ["0"]
for i, item in enumerate(json_obj):
    person = (validate_string(item.get("person", None)))[0]
    year = validate_string(item.get("year", None))[0]
    company = validate_string(item.get("company", None))[0]

    cursor.execute("INSERT INTO temp (title,author,tag) VALUES (%s,	%s,	%s)", (person, year, company))
con.commit()
con.close()